Mahamaya Waterproofing website
1. Extract this ZIP.
2. Upload index.html to the root of your GitHub Pages repository and commit.
3. Supabase project URL and publishable key are set in index.html.
4. Never put a Supabase secret/service_role key in public website code.
5. The bookings table must have: customer_name, mobile, address, problem, square_feet, booking_status, created_at.
6. Supabase RLS should allow anonymous INSERT only, and authenticated admin SELECT only for the intended admin account.
