# महमाया वाटरप्रूफिंग — ऑनलाइन बुकिंग वेबसाइट

इस प्रोजेक्ट में ग्राहक के लिए सार्वजनिक बुकिंग फॉर्म और मालिक के लिए पासवर्ड-सुरक्षित एडमिन डैशबोर्ड है।

## इसमें क्या है
- ग्राहक नाम, मोबाइल, पता, समस्या, गंभीरता, पसंदीदा तारीख/समय, विवरण और लीड स्रोत भेज सकता है।
- रिकॉर्ड सर्वर के SQLite डेटाबेस में सेव होते हैं; ब्राउज़र के localStorage में नहीं।
- एडमिन लॉगिन के बाद लीड खोज सकता है, स्टेटस बदल सकता है, WhatsApp पर संपर्क कर सकता है, CSV डाउनलोड कर सकता है और रिकॉर्ड हटा सकता है।
- पासवर्ड plain text में नहीं रखा जाता; bcrypt hash इस्तेमाल होता है।
- Secure session cookie, Helmet security headers, login/public booking rate limits और server-side validation शामिल हैं।

## अपने कंप्यूटर पर चलाना
ज़रूरी: Node.js 20 या नया।

1. इस ZIP को extract करें।
2. टर्मिनल में प्रोजेक्ट फोल्डर खोलें और `npm install` चलाएँ।
3. `.env.example` की कॉपी बनाकर `.env` नाम दें।
4. पासवर्ड का bcrypt hash बनाएँ। उदाहरण:
   `node -e "require('bcryptjs').hash('YahanApnaMajbootPassword',12).then(console.log)"`
   आउटपुट को `.env` में `ADMIN_PASSWORD_HASH=` के बाद रखें। असली पासवर्ड किसी के साथ साझा न करें।
5. `.env` में `SESSION_SECRET` को कम से कम 32 अक्षरों की अलग, लंबी random string से बदलें। `ADMIN_USERNAME` और दुकान की जानकारी भी भरें।
6. `npm start` चलाएँ और `http://localhost:3000` खोलें। एडमिन के लिए `http://localhost:3000/admin.html` खोलें।

## Render पर इंटरनेट पर प्रकाशित करना
यह ZIP अभी सार्वजनिक इंटरनेट पर प्रकाशित नहीं है। प्रकाशित करने के लिए आपके अपने Render खाते की ज़रूरत होगी।

1. ZIP को extract करें और पूरा प्रोजेक्ट अपने निजी GitHub repository में डालें।
2. Render में **New → Blueprint** चुनें और उस repository को connect करें; `render.yaml` से सेवा बन सकती है।
3. Render की Environment settings में ये secrets भरें:
   - `ADMIN_USERNAME`: अपना पसंदीदा admin username
   - `ADMIN_PASSWORD_HASH`: ऊपर बनाया हुआ bcrypt hash
   - `SHOP_WHATSAPP`: देश कोड सहित केवल अंक, उदाहरण `91XXXXXXXXXX` (खाली छोड़ सकते हैं)
4. सुनिश्चित करें कि Persistent Disk `/var/data` पर mount है। `DB_PATH=/var/data/mahamaya.sqlite` रहना चाहिए, ताकि deploy के बाद रिकॉर्ड बने रहें।
5. Deploy पूरा होने पर Render का दिया हुआ `https://...onrender.com` URL खोलें। एडमिन पेज उसी URL के साथ `/admin.html` है।
6. सार्वजनिक बुकिंग और एडमिन लॉगिन दोनों की जाँच एक टेस्ट बुकिंग से करें।

## सुरक्षा और सीमाएँ
- `ADMIN_PASSWORD_HASH` में bcrypt hash रखें, असली पासवर्ड नहीं।
- `.env` या credentials GitHub में कभी commit न करें।
- Render persistent disk आम तौर पर paid service की आवश्यकता रख सकता है; अपने खाते में वर्तमान कीमत और disk support जाँचें।
- अभी ईमेल/SMS notifications और automatic WhatsApp notifications नहीं हैं। एडमिन डैशबोर्ड में रिकॉर्ड देखने और ग्राहक को WhatsApp खोलकर संदेश भेजने की सुविधा है।
- लाइव वेबसाइट बनाने के लिए होस्टिंग अकाउंट, secrets सेट करना और deploy करना आवश्यक है। इस पैकेज को अपने आप इंटरनेट पर प्रकाशित नहीं किया गया है।
- ग्राहक की निजी जानकारी संभालने से पहले अपनी गोपनीयता सूचना और डेटा रखने/हटाने की नीति तय करें।
