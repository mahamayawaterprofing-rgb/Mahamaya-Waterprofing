require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');

const app = express();
const port = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';
const secret = process.env.SESSION_SECRET || '';
const adminUsername = process.env.ADMIN_USERNAME || '';
const adminPasswordHash = process.env.ADMIN_PASSWORD_HASH || '';
const dbPath = process.env.DB_PATH || './data/mahamaya.sqlite';

if (secret.length < 32) {
  console.error('FATAL: SESSION_SECRET must be at least 32 characters. Configure it in your environment.');
  process.exit(1);
}
if (!adminUsername || !adminPasswordHash || !adminPasswordHash.startsWith('$2')) {
  console.error('FATAL: Set ADMIN_USERNAME and a valid bcrypt ADMIN_PASSWORD_HASH before starting.');
  process.exit(1);
}
fs.mkdirSync(path.dirname(path.resolve(dbPath)), { recursive: true });
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS leads (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 name TEXT NOT NULL,
 phone TEXT NOT NULL,
 address TEXT NOT NULL,
 problem TEXT NOT NULL,
 urgency TEXT NOT NULL DEFAULT 'सामान्य',
 visit_date TEXT,
 visit_time TEXT,
 details TEXT,
 source TEXT,
 status TEXT NOT NULL DEFAULT 'नई पूछताछ'
);
CREATE TABLE IF NOT EXISTS sessions (
 sid TEXT PRIMARY KEY,
 sess TEXT NOT NULL,
 expired INTEGER NOT NULL
);
`);
const insertLead = db.prepare(`INSERT INTO leads
(name,phone,address,problem,urgency,visit_date,visit_time,details,source)
VALUES (@name,@phone,@address,@problem,@urgency,@visit_date,@visit_time,@details,@source)`);
const validProblems = new Set(['छत से पानी टपकना','दीवार में सीलन','बाथरूम / टॉयलेट लीकेज','टंकी लीकेज','बेसमेंट में पानी','नई छत की वाटरप्रूफिंग','अन्य']);
const validUrgency = new Set(['सामान्य','जल्द से जल्द','बहुत जरूरी / पानी अभी टपक रहा है']);
const validSources = new Set(['Instagram','WhatsApp','Google','रेफरेंस / जान-पहचान','बैनर / दुकान','अन्य']);
const validStatuses = new Set(['नई पूछताछ','ग्राहक से बात करनी है','बुकिंग तय','काम पूरा','रद्द']);

app.disable('x-powered-by');
if (isProd) app.set('trust proxy', 1);
app.use(helmet({
 contentSecurityPolicy: {
  directives: {
   defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'","'unsafe-inline'"],
   imgSrc: ["'self'","data:"], connectSrc: ["'self'"], objectSrc: ["'none'"],
   baseUri: ["'self'"], frameAncestors: ["'none'"], formAction: ["'self'"]
  }
 }
}));
app.use(express.json({limit:'20kb'}));
app.use(express.urlencoded({extended:false,limit:'20kb'}));
app.use(session({
 name: 'mahamaya.sid',
 secret,
 resave: false,
 saveUninitialized: false,
 store: new SQLiteStore({db: 'sessions.sqlite', dir: path.dirname(path.resolve(dbPath))}),
 cookie: { httpOnly:true, sameSite:'strict', secure:isProd, maxAge: 8*60*60*1000 },
 rolling: true
}));
const loginLimiter = rateLimit({windowMs:15*60*1000,limit:8,standardHeaders:true,legacyHeaders:false,message:{error:'बहुत बार प्रयास हुआ। 15 मिनट बाद फिर कोशिश करें।'}});
const bookingLimiter = rateLimit({windowMs:60*60*1000,limit:12,standardHeaders:true,legacyHeaders:false,message:{error:'अभी बहुत सारी बुकिंग कोशिशें हुई हैं। बाद में फिर कोशिश करें।'}});
const adminLimiter = rateLimit({windowMs:15*60*1000,limit:120,standardHeaders:true,legacyHeaders:false});
const clean = (v,max=500) => typeof v === 'string' ? v.trim().slice(0,max) : '';
const isLoggedIn = (req,res,next) => req.session && req.session.admin === true ? next() : res.status(401).json({error:'लॉगिन आवश्यक है।'});
const meta = () => ({shopName:process.env.SHOP_NAME || 'महमाया वाटरप्रूफिंग',shopArea:process.env.SHOP_AREA || '',shopWhatsApp:(process.env.SHOP_WHATSAPP||'').replace(/\D/g,'')});

app.get('/api/health',(req,res)=>res.json({ok:true}));
app.get('/api/public-config',(req,res)=>res.json(meta()));
app.post('/api/bookings',bookingLimiter,(req,res)=>{
 const body=req.body||{};
 const name=clean(body.name,100), phone=clean(body.phone,20), address=clean(body.address,300);
 const problem=clean(body.problem,100);
 if(name.length<2 || !/^[0-9+\s()-]{10,20}$/.test(phone) || address.length<4 || !validProblems.has(problem)) {
  return res.status(400).json({error:'कृपया नाम, सही मोबाइल नंबर, पूरा पता और समस्या भरें।'});
 }
 const urgency=validUrgency.has(body.urgency)?body.urgency:'सामान्य';
 const source=validSources.has(body.source)?body.source:'अन्य';
 const visitDate=/^\d{4}-\d{2}-\d{2}$/.test(clean(body.visit_date,10))?clean(body.visit_date,10):null;
 const visitTime=clean(body.visit_time,40);
 try {
  const result=insertLead.run({name,phone,address,problem,urgency,visit_date:visitDate,visit_time:visitTime,details:clean(body.details,2000),source});
  res.status(201).json({ok:true,id:result.lastInsertRowid,message:'आपकी बुकिंग की जानकारी मिल गई है। महमाया वाटरप्रूफिंग की टीम आपसे संपर्क करेगी।'});
 } catch(e) { console.error(e); res.status(500).json({error:'जानकारी सेव नहीं हो सकी। कृपया दोबारा कोशिश करें।'}); }
});
app.post('/api/admin/login',loginLimiter,async(req,res)=>{
 const username=clean(req.body?.username,100), password=typeof req.body?.password==='string'?req.body.password:'';
 let okay=false;
 try { okay=username===adminUsername && await bcrypt.compare(password,adminPasswordHash); } catch {}
 if(!okay) return res.status(401).json({error:'यूज़रनेम या पासवर्ड सही नहीं है।'});
 req.session.regenerate(err=>{
  if(err) return res.status(500).json({error:'लॉगिन नहीं हो सका।'});
  req.session.admin=true; req.session.user=adminUsername;
  req.session.save(err2=>err2?res.status(500).json({error:'सेशन सेव नहीं हो सका।'}):res.json({ok:true,user:adminUsername}));
 });
});
app.post('/api/admin/logout',(req,res)=>req.session.destroy(()=>{res.clearCookie('mahamaya.sid');res.json({ok:true});}));
app.get('/api/admin/me',(req,res)=>res.json({loggedIn:!!(req.session&&req.session.admin),user:req.session?.admin?req.session.user:null}));
app.get('/api/admin/leads',isLoggedIn,adminLimiter,(req,res)=>{
 const status=clean(req.query.status,50);
 const q=clean(req.query.q,120);
 let rows=db.prepare('SELECT * FROM leads ORDER BY id DESC').all();
 if(status && status!=='सभी') rows=rows.filter(x=>x.status===status);
 if(q){const term=q.toLocaleLowerCase('hi');rows=rows.filter(x=>[x.name,x.phone,x.address,x.problem,x.details,x.source].join(' ').toLocaleLowerCase('hi').includes(term));}
 res.json({leads:rows,counts:{
  total:db.prepare('SELECT COUNT(*) n FROM leads').get().n,
  fresh:db.prepare("SELECT COUNT(*) n FROM leads WHERE status='नई पूछताछ'").get().n,
  booked:db.prepare("SELECT COUNT(*) n FROM leads WHERE status='बुकिंग तय'").get().n,
  done:db.prepare("SELECT COUNT(*) n FROM leads WHERE status='काम पूरा'").get().n
 }});
});
app.patch('/api/admin/leads/:id',isLoggedIn,adminLimiter,(req,res)=>{
 const id=Number(req.params.id), status=clean(req.body?.status,50);
 if(!Number.isSafeInteger(id)||id<1||!validStatuses.has(status)) return res.status(400).json({error:'रिकॉर्ड या स्टेटस सही नहीं है।'});
 const result=db.prepare('UPDATE leads SET status=? WHERE id=?').run(status,id);
 if(!result.changes) return res.status(404).json({error:'रिकॉर्ड नहीं मिला।'});
 res.json({ok:true});
});
app.delete('/api/admin/leads/:id',isLoggedIn,adminLimiter,(req,res)=>{
 const id=Number(req.params.id);
 if(!Number.isSafeInteger(id)||id<1) return res.status(400).json({error:'रिकॉर्ड सही नहीं है।'});
 const result=db.prepare('DELETE FROM leads WHERE id=?').run(id);
 if(!result.changes) return res.status(404).json({error:'रिकॉर्ड नहीं मिला।'});
 res.json({ok:true});
});
app.get('/api/admin/export.csv',isLoggedIn,adminLimiter,(req,res)=>{
 const rows=db.prepare('SELECT created_at,name,phone,address,problem,urgency,visit_date,visit_time,details,source,status FROM leads ORDER BY id DESC').all();
 const keys=Object.keys(rows[0]||{created_at:'',name:'',phone:'',address:'',problem:'',urgency:'',visit_date:'',visit_time:'',details:'',source:'',status:''});
 const csv=[keys.join(','),...rows.map(row=>keys.map(k=>'"'+String(row[k]??'').replace(/"/g,'""')+'"').join(','))].join('\r\n');
 res.setHeader('Content-Type','text/csv; charset=utf-8');
 res.setHeader('Content-Disposition','attachment; filename="mahamaya-leads.csv"');
 res.send('\ufeff'+csv);
});
app.use(express.static(path.join(__dirname,'public'),{extensions:['html'],maxAge:isProd?'1h':0}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(port,()=>console.log(`Mahamaya Waterproofing app listening on ${port}`));
